function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");

    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.hash);

	// console.log('getParameterByName');

    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

/*
returns the value of query param
*/