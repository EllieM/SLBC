// Jquery validate form College contact

$.validator.setDefaults({
	submitHandler: function() { alert("submitted!"); }
});


$(document).ready(function(){
	// validate signup form on keyup and submit
	$("#CollegeContactform").validate({
		rules: {
			firstname: "required",
			lastname: "required",
			email: {
				required: true,
				email: true
			},
			phone_f: "required",
			message: "required"
		},
		messages: {
			firstname: "Required",
			lastname: "Required",
			email: "Please enter a valid email address",
			phone_f: "Required",
			message: "Required"
		}
	});

	$("#SeminaryContactform").validate({
		rules: {
			firstname: "required",
			lastname: "required",
			email: {
				required: true,
				email: true
			},
			phone_f: "required",
			message: "required"
		},
		messages: {
			firstname: "Required",
			lastname: "Required",
			email: "Please enter a valid email address",
			phone_f: "Required",
			message: "Required"
		}
	});	
	
});






